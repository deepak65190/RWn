$(document).ready(function(){
    $('.main').slick({
        slidesToShow: 1,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 5000,
      });
})